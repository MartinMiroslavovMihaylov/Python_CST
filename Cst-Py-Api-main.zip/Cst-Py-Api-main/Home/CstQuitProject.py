def CstQuitProject(mws):
    mws.Quit()
