def CstSaveAsProject(mws, projectName):
    mws.SaveAs(projectName + '.cst', 'false')
