def CstSaveProject(mws):
    mws.Save()
