def CstAdd(mws, component1, compenent2):
    solid = mws.Solid

    solid.Add(component1, compenent2)
