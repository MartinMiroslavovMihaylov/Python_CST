def CstAlignWCSwithFace(mws):
    wcs = mws.WCS

    wcs.AlignWCSWithSelected('Face')
