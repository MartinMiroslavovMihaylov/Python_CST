def CstAlignWCSwithPoint(mws):
    wcs = mws.WCS

    wcs.AlignWCSWithSelected('Point')
