def CstClearPicks(mws):
    pick = mws.Pick

    pick.ClearAllPicks()
